Development moved to https://gitlab.com/blacknet-ninja

https://blackcoin.org/ aims to continue on BlackCoin chain.
